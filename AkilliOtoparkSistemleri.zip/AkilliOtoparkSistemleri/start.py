from AkilliOtopark import app, db

